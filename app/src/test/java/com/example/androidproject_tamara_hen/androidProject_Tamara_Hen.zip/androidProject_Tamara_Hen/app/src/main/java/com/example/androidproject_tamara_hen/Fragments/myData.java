package com.example.androidproject_tamara_hen.Fragments;

import com.example.androidproject_tamara_hen.R;

public class myData {

    static String[] nameArray = {"The Pink Teddy Bear", "Friends Mug", "Blessing card", "Gus Fring"
            ,"Mike Ehrmantraut", "Saul Goodman", "Skyler White"
            ,"Walter White JR", "Nacho Varga", "Lalo Salamanca"};
    static String[] versionArray = {
            "“Say My Name” with the Iconic Pink Teddy Bear!\n" +
                    "\n" +
                    "Inspired by the legendary series Breaking Bad, this adorable yet rebellious pink teddy bear is more than just a cuddle buddy – it’s a symbol of the wild ride through Albuquerque’s underworld. Whether you’re a fan of Walter White’s transformation or just love the nostalgia of one of the greatest shows ever, this bear brings a touch of the unexpected. Soft, squishy, and totally unique, it's the perfect gift for Breaking Bad fans who appreciate a little whimsy with their danger."
            , "“You don’t have to be a coffee lover to enjoy the Central Perk experience!”\n" +
            "Sip your favorite brew from the iconic Central Perk mug, and feel like you’re catching up with Monica, Chandler, Ross, Rachel, Joey, and Phoebe in their favorite NYC coffee shop. "
            , "Inspired by the heartwarming moment from The Simpsons ,the card Raphael gave to Lisa, this card of love and the beauty of life’s simple blessings. "
            , "Head of his drug empire"
            , "5", "6", "7", "8", "9","10"};

    static Integer[] drawableArray = {R.drawable.pinkbear, R.drawable.friendsmug, R.drawable.trainblessing,
            R.drawable.deadpool_funko_pop, R.drawable.deadpool_funko_pop, R.drawable.deadpool_funko_pop,
            R.drawable.deadpool_funko_pop, R.drawable.deadpool_funko_pop, R.drawable.deadpool_funko_pop,R.drawable.deadpool_funko_pop};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

}
