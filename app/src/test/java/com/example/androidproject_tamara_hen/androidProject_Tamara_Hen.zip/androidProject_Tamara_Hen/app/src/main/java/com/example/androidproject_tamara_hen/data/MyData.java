package com.example.androidproject_tamara_hen.data;

import com.example.androidproject_tamara_hen.R;

public class MyData {

    public static String[] nameArray = {"Invincible", "Loofy the Monkey", "Carl and Ellie", "Chackie"
            ,"Poofy", "Ang the last air bender", "Cat in Boots"
            ,"Mark's cup", "Iron-man", "Vulture"};
    public static String[] versionArray = {
            " $9"
            , "one piece unique statue $22"
            , "the iconic up figures $50"
            , "our newest character $44"
            , "our inside out figure $63"
            , "the nostalgic avatar figure $100"
            , "puss in boots $70"
            , "invincible mug $10"
            , "iron man $33"
            , "falco from spiderman $77"

            , "5", "6", "7", "8", "9","10"};

    public static Integer[] drawableArray = {R.drawable.deadpool_funko_pop, R.drawable.friendsmug, R.drawable.pinkbear,
            R.drawable.trainblessing, R.drawable.funko_pop_moments_d100_carl_and_amp_ellie_old_1, R.drawable.homelogo,R.drawable.merchverse4,R.drawable.ic_launcher_foreground,R.drawable.merchverse,R.drawable.pinkbear};

    public static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

}
