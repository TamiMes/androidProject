package com.example.androidproject_tamara_hen;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import Ui.Cart;

public class CartViewModel extends ViewModel {

    private final MutableLiveData<Cart> cartLiveData = new MutableLiveData<>();


}
